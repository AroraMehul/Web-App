import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mifosx-view-loan',
  templateUrl: './view-loan.component.html',
  styleUrls: ['./view-loan.component.scss']
})
export class ViewLoanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
